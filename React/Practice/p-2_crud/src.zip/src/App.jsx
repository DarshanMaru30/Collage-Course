import { useState } from 'react'
import './App.css'
import Home from './Cwomponent/Home'

function App() {

  return (
    <>
      <Home/>
    </>
  )
}

export default App
